package com.packt.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
